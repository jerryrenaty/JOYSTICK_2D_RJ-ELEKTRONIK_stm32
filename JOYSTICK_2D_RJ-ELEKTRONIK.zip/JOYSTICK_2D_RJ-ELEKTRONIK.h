/*
 * JOYSTICK_2D_RJ-ELEKTRONIK.h
 *
 *  Created on: 5 juil. 2026
 *      Author: RENATYJERRY
 */

#ifndef INC_JOYSTICK_2D_RJ_ELEKTRONIK_H_
#define INC_JOYSTICK_2D_RJ_ELEKTRONIK_H_


#include "main.h"


/* ======================== CONFIGURATION DEBUG ======================== */
#define DEBUG_JOYSTICK   1   /* 1 = activé, 0 = désactivé */

#if DEBUG_JOYSTICK
#include "PORT_SERIAL_DEBUG_RJ-ELEKTRONIK.h"   /* Pour debug_println */
    #define JOYSTICK_DEBUG(fmt, ...)  debug_println("[JOYSTICK] " fmt "\r\n", ##__VA_ARGS__)
#else
    #define JOYSTICK_DEBUG(fmt, ...)  ((void)0)
#endif
/* ====================================================================== */

/* Configurations de la bibliothèque */
#define JOY_SAMPLES_PER_AXIS  8   // Nombre d'échantillons pour la moyenne (doit être puissance de 2)
#define JOY_TOTAL_SAMPLES     (JOY_SAMPLES_PER_AXIS * 2) // X et Y alternés
#define JOY_ADC_RESOLUTION    65535.0f // Résolution 16 bits de l'ADC du STM32H7

/* Structure de configuration et d'état du Joystick */
typedef struct {
    ADC_HandleTypeDef *hadc;    // Pointeur vers l'instance ADC (ex: &hadc1)
    uint16_t deadzone;          // Valeur de la zone morte (ex: 500 à 1500)
    uint16_t center_X;          // Valeur brute mesurée au centre pour X
    uint16_t center_Y;          // Valeur brute mesurée au centre pour Y

    // Valeurs filtrées et lissées finales (0 à 65535)
    uint16_t raw_X;
    uint16_t raw_Y;

    // Valeurs normalisées utiles pour le contrôle (-1.0f à 1.0f)
    float norm_X;
    float norm_Y;

    uint8_t is_initialized;     // Flag de sécurité
} Joystick_t;

/* Statuts de retour pour la sécurité du code */
typedef enum {
    JOY_OK = 0,
    JOY_ERROR_NULL_PTR,
    JOY_ERROR_NOT_READY
} Joy_Status_t;

/* Prototypes des fonctions publiques */
Joy_Status_t Joystick_Init(Joystick_t *joy, ADC_HandleTypeDef *hadc, uint16_t deadzone);
Joy_Status_t Joystick_Calibrate(Joystick_t *joy);
Joy_Status_t Joystick_Update(Joystick_t *joy);
Joy_Status_t Joystick_DebugPrint(Joystick_t *joy);


#endif /* INC_JOYSTICK_2D_RJ_ELEKTRONIK_H_ */
