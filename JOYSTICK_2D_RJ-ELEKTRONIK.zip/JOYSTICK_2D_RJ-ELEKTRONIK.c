/**
  * @file    JOYSTICK.c
  * @author  RJ-ELEKTRONIK
  * @brief   Driver pour joystick analogique avec ADC et DMA
  * @version 2.0 (avec debug intégré)
  */

#include "JOYSTICK_2D_RJ-ELEKTRONIK.h"
#include <stdlib.h>  /* pour abs() */

// Compatible avec le script d'édition de liens de STM32CubeIDE
ALIGN_32BYTES(static uint16_t dma_adc_buffer[JOY_TOTAL_SAMPLES]);

/**
  * @brief  Initialise la structure du joystick et démarre le DMA.
  * @param  joy: Pointeur vers la structure du joystick.
  * @param  hadc: Pointeur vers le périphérique HAL ADC configuré.
  * @param  deadzone: Rayon de la zone morte autour du centre matériel.
  * @retval JOY_OK si succès, sinon code d'erreur
  */
Joy_Status_t Joystick_Init(Joystick_t *joy, ADC_HandleTypeDef *hadc, uint16_t deadzone)
{
    JOYSTICK_DEBUG("Joystick_Init: début");

    // Sécurité : Vérification des pointeurs nuls
    if (joy == NULL || hadc == NULL) {
        JOYSTICK_DEBUG("Joystick_Init: ERREUR - pointeur NULL");
        return JOY_ERROR_NULL_PTR;
    }

    joy->hadc = hadc;
    joy->deadzone = deadzone;
    joy->center_X = 32768; // Valeurs théoriques par défaut (mi-échelle 16 bits)
    joy->center_Y = 32768;
    joy->raw_X = 32768;
    joy->raw_Y = 32768;
    joy->norm_X = 0.0f;
    joy->norm_Y = 0.0f;
    joy->is_initialized = 0;

    JOYSTICK_DEBUG("Joystick_Init: deadzone=%d, centre par défaut X=%d Y=%d", deadzone, joy->center_X, joy->center_Y);

    // Démarrage de l'ADC en mode DMA Circulaire pour remplir notre buffer aligné
    if (HAL_ADC_Start_DMA(joy->hadc, (uint32_t*)dma_adc_buffer, JOY_TOTAL_SAMPLES) != HAL_OK) {
        JOYSTICK_DEBUG("Joystick_Init: ERREUR - démarrage DMA ADC");
        return JOY_ERROR_NOT_READY;
    }

    joy->is_initialized = 1;
    JOYSTICK_DEBUG("Joystick_Init: succès");
    return JOY_OK;
}

/**
  * @brief  Calibre le centre du joystick. À appeler au démarrage quand le joystick est au repos.
  * @param  joy: Pointeur vers la structure du joystick.
  * @retval JOY_OK si succès, sinon code d'erreur
  */
Joy_Status_t Joystick_Calibrate(Joystick_t *joy)
{
    JOYSTICK_DEBUG("Joystick_Calibrate: début");

    if (joy == NULL || !joy->is_initialized) {
        JOYSTICK_DEBUG("Joystick_Calibrate: ERREUR - non initialisé");
        return JOY_ERROR_NOT_READY;
    }

    // Attendre quelques millisecondes que le DMA stabilise le premier enregistrement
    HAL_Delay(50);

    // On met à jour les données brutes une première fois
    Joystick_Update(joy);

    // On mémorise la position physique actuelle comme le centre parfait du joystick
    joy->center_X = joy->raw_X;
    joy->center_Y = joy->raw_Y;

    JOYSTICK_DEBUG("Joystick_Calibrate: centre X=%d, centre Y=%d", joy->center_X, joy->center_Y);
    return JOY_OK;
}

/**
  * @brief  Filtre, traite la zone morte et met à jour les valeurs du Joystick.
  *         Doit être appelée périodiquement (ex: toutes les 20ms dans le while).
  * @param  joy: Pointeur vers la structure du joystick.
  * @retval JOY_OK si succès, sinon code d'erreur
  */
Joy_Status_t Joystick_Update(Joystick_t *joy)
{
    if (joy == NULL || !joy->is_initialized) {
        return JOY_ERROR_NOT_READY;
    }

    uint32_t sum_X = 0;
    uint32_t sum_Y = 0;

    /* SÉCURITÉ MATÉRIELLE STM32H7 : Invalidation obligatoire du Cache */
    // Force l'architecture à aller lire la vraie RAM mise à jour par le DMA
    SCB_InvalidateDCache_by_Addr((uint32_t*)dma_adc_buffer, sizeof(dma_adc_buffer));

    /* 1. Traitement du filtrage (Moyenne glissante sur le buffer DMA) */
    // CubeMX configuré en scan alterné remplira le buffer ainsi : [X0, Y0, X1, Y1, X2, Y2...]
    for (uint32_t i = 0; i < JOY_TOTAL_SAMPLES; i += 2) {
        sum_X += dma_adc_buffer[i];
        sum_Y += dma_adc_buffer[i + 1];
    }

    joy->raw_X = (uint16_t)(sum_X / JOY_SAMPLES_PER_AXIS);
    joy->raw_Y = (uint16_t)(sum_Y / JOY_SAMPLES_PER_AXIS);

    /* 2. Application de la Zone Morte et Normalisation (-1.0 à 1.0) */
    int32_t delta_X = (int32_t)joy->raw_X - (int32_t)joy->center_X;
    int32_t delta_Y = (int32_t)joy->raw_Y - (int32_t)joy->center_Y;

    // Gestion de la zone morte sur l'axe X
    if (abs(delta_X) < joy->deadzone) {
        joy->norm_X = 0.0f;
    } else {
        if (delta_X > 0) {
            joy->norm_X = (float)(delta_X - joy->deadzone) / (JOY_ADC_RESOLUTION - joy->center_X - joy->deadzone);
        } else {
            joy->norm_X = (float)(delta_X + joy->deadzone) / (joy->center_X - joy->deadzone);
        }
    }

    // Gestion de la zone morte sur l'axe Y
    if (abs(delta_Y) < joy->deadzone) {
        joy->norm_Y = 0.0f;
    } else {
        if (delta_Y > 0) {
            joy->norm_Y = (float)(delta_Y - joy->deadzone) / (JOY_ADC_RESOLUTION - joy->center_Y - joy->deadzone);
        } else {
            joy->norm_Y = (float)(delta_Y + joy->deadzone) / (joy->center_Y - joy->deadzone);
        }
    }

    // Sécurité de saturation des flottants pour rester strictement entre -1.0 et 1.0
    if (joy->norm_X > 1.0f)  joy->norm_X = 1.0f;
    if (joy->norm_X < -1.0f) joy->norm_X = -1.0f;
    if (joy->norm_Y > 1.0f)  joy->norm_Y = 1.0f;
    if (joy->norm_Y < -1.0f) joy->norm_Y = -1.0f;

    // Debug optionnel : affichage uniquement si les valeurs changent significativement
    // (décommentez si nécessaire, mais peut saturer la console)
    // static uint16_t last_print_X = 0, last_print_Y = 0;
    // if (abs(joy->raw_X - last_print_X) > 1000 || abs(joy->raw_Y - last_print_Y) > 1000) {
    //     JOYSTICK_DEBUG("Update: raw X=%d Y=%d, norm X=%.2f Y=%.2f", joy->raw_X, joy->raw_Y, joy->norm_X, joy->norm_Y);
    //     last_print_X = joy->raw_X;
    //     last_print_Y = joy->raw_Y;
    // }

    return JOY_OK;
}

/**
  * @brief  Affiche les paramètres actuels du joystick sur le port série.
  * @param  joy: Pointeur vers la structure du joystick.
  * @retval JOY_OK si succès, sinon code d'erreur
  */
Joy_Status_t Joystick_DebugPrint(Joystick_t *joy)
{
    static uint8_t debug_once = 0;

    if (joy == NULL) {
        JOYSTICK_DEBUG("Joystick_DebugPrint: ERREUR - pointeur NULL");
        return JOY_ERROR_NULL_PTR;
    }

    if (!debug_once) {
        JOYSTICK_DEBUG("=== JOYSTICK DEBUG ===");
        JOYSTICK_DEBUG("Centre: X=%d, Y=%d", joy->center_X, joy->center_Y);
        JOYSTICK_DEBUG("Deadzone: %d", joy->deadzone);
        JOYSTICK_DEBUG("Initialisé: %s", joy->is_initialized ? "OUI" : "NON");
        debug_once = 1;
    }

    JOYSTICK_DEBUG("Raw: X=%d, Y=%d", joy->raw_X, joy->raw_Y);
    JOYSTICK_DEBUG("Norm: X=%.3f, Y=%.3f", joy->norm_X, joy->norm_Y);

    return JOY_OK;
}

/**
  * @brief  Mappe une valeur flottante de manière linéaire avec protection mathématique.
  * @param  value: Valeur à mapper
  * @param  in_min: Borne min de la plage d'entrée
  * @param  in_max: Borne max de la plage d'entrée
  * @param  out_min: Borne min de la plage de sortie
  * @param  out_max: Borne max de la plage de sortie
  * @retval Valeur mappée et saturée
  */
float Joystick_MapFloat(float value, float in_min, float in_max, float out_min, float out_max)
{
    JOYSTICK_DEBUG("MapFloat: value=%.3f, in=[%.3f,%.3f], out=[%.3f,%.3f]", value, in_min, in_max, out_min, out_max);

    // Sécurité : évite la division par zéro si la plage d'entrée est invalide
    if (in_max == in_min) {
        JOYSTICK_DEBUG("MapFloat: ERREUR - plage d'entrée nulle");
        return out_min;
    }

    // Formule mathématique classique d'interpolation linéaire
    float mapped = (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

    // Saturation de sécurité pour ne jamais dépasser les bornes de sortie demandées
    if (out_min < out_max) {
        if (mapped < out_min) mapped = out_min;
        if (mapped > out_max) mapped = out_max;
    } else {
        if (mapped > out_min) mapped = out_min;
        if (mapped < out_max) mapped = out_max;
    }

    JOYSTICK_DEBUG("MapFloat: résultat = %.3f", mapped);
    return mapped;
}

/**
  * @brief  Mappe une valeur entière avec protection et sans calculs flottants lourds.
  * @param  value: Valeur à mapper
  * @param  in_min: Borne min de la plage d'entrée
  * @param  in_max: Borne max de la plage d'entrée
  * @param  out_min: Borne min de la plage de sortie
  * @param  out_max: Borne max de la plage de sortie
  * @retval Valeur mappée et saturée
  */
int32_t Joystick_MapInt(int32_t value, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max)
{
    JOYSTICK_DEBUG("MapInt: value=%d, in=[%d,%d], out=[%d,%d]", value, in_min, in_max, out_min, out_max);

    if (in_max == in_min) {
        JOYSTICK_DEBUG("MapInt: ERREUR - plage d'entrée nulle");
        return out_min;
    }

    int32_t mapped = (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

    if (out_min < out_max) {
        if (mapped < out_min) mapped = out_min;
        if (mapped > out_max) mapped = out_max;
    } else {
        if (mapped > out_min) mapped = out_min;
        if (mapped < out_max) mapped = out_max;
    }

    JOYSTICK_DEBUG("MapInt: résultat = %d", mapped);
    return mapped;
}
